angular.module("ToDoList",["LocalStorageModule"])
.controller("ToDoController", function($scope,LocalStorageService){

})